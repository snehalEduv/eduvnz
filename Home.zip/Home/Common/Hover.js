import React from 'react';
import HoverComponent from './HoverComponent';
import './HoverComponent.css';



 

const Hover=()=>{
    return(
    <div>

           {/* <div>
                <h3> APPLY FOR EDUVANZ LOANS </h3>
                <p> Step Towards a Brighter Future with Eduvanz Loan Find out how </p>
            </div>
             */}
            
            <div class="container">
            <div class="row" align="center">
                <div class="col-md-3 zoom wow pulse applyAnimation padd" data-wow-duration="1s">
                    <HoverComponent header='1. Select' text='Choose your desired. Institute and course' src='https://d1idiaqkpcnv43.cloudfront.net/assets/webimages/select.png'></HoverComponent>
                </div>
                <div class="col-md-3 zoom wow pulse applyAnimation padd" data-wow-duration="1s">
                    <HoverComponent header='2. Apply' text="Provide and verify your details and documents online." src="https://d1idiaqkpcnv43.cloudfront.net/assets/webimages/apply.png"></HoverComponent>
                </div>
                <div class="col-md-3 zoom wow pulse applyAnimation padd" data-wow-duration="1s">
                    <HoverComponent header='3. Approval' text='On the spot approval and instant support from our loan advisors.' src='https://d1idiaqkpcnv43.cloudfront.net/assets/webimages/sanction.png'></HoverComponent>
                </div>
                <div class="col-md-3 zoom wow pulse applyAnimation padd" data-wow-duration="1s">
                    <HoverComponent header='4. Learn and Repay' text='Loan disbursed to your institute as you repay in flexible EMIs.' src='https://d1idiaqkpcnv43.cloudfront.net/assets/webimages/disbursal.png'></HoverComponent>
                </div>
                
            </div>
            </div>
        

        
           
    </div> 

    );
}
export default Hover;